Fast C Short Path chinese and english cut


